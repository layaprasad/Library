let mail = document.getElementById("mail");
let pwd = document.getElementById("pwd");
let errorMail = document.getElementById("errorMail");
let errorPwd = document.getElementById("errorPwd");

let mailRegex = /^([A-Za-z0-9\.-]+)@([A-Za-z0-9\-]+)\.([a-z]{2,3})(\.[a-z{2,3}])?$/ ;
// let pwdRegex ;


function validate(){
    if(mail.value == ""){
        errorMail.innerHTML = "Email id should not be blank";
        errorMail.style.color = "white";
        errorMail.style.fontSize = "smaller";
        return false;
    }
    else if(mailRegex.test(mail.value) == false){
        errorMail.innerHTML = "Email id is Invalid";
        errorMail.style.color = "white";
        errorMail.style.fontSize = "smaller";
        return false;
    }
    else if(pwd.value == ""){
        errorPwd.innerHTML = "Password should not be empty";
        errorPwd.style.color = "white";
        errorPwd.style.fontSize = "smaller";
        return false;
    }     
    else{
        errorPwd.innerHTML = "";
        errorMail.innerHTML ="";
        return true;
    }
}
     
    
// function mailid(){
//     if(mail.value == ""){
//         errorMail.innerHTML = "Email id should not be blank";
//         errorMail.style.color = "white";
//         errorMail.style.fontSize = "smaller";
//         return false;
//     }
//     else if(mailRegex.test(mail.value) == false){
//         errorMail.innerHTML = "Email id is Invalid";
//         errorMail.style.color = "white";
//         errorMail.style.fontSize = "smaller";
//         return false;
//     }
//     else{
//         errorMail.innerHTML = ""; 
//     }
    
// }
// function password(){
//     if(pwd.value == ""){
//         errorPwd.innerHTML = "Password should not be empty";
//         errorPwd.style.color = "white";
//         errorPwd.style.fontSize = "smaller";
//         return false;
//     }     
//     else{
//         errorPwd.innerHTML = "";
//         return true;
//     }
// }